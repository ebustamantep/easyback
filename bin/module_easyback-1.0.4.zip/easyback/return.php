<?php
/* Copyright (C) 2026		Edgar Bustamante	<ebustamantep@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    easyback/return.php
 * \ingroup easyback
 * \brief   Popup to process a return. Two modes:
 *          - PARTIAL (invoice card): only the selected lines/quantities are
 *            returned, and the equivalent money is refunded, prorated across
 *            the payment channels the operator marks.
 *          - TOTAL (invoice card "Devolución total" / POS): the whole invoice is
 *            returned (all lines, full quantities) and every payment is refunded
 *            in full, each in its own channel/bank.
 */

define('NOTOKENRENEWAL', 1);
define('NOREQUIREMENU', 1);
define('NOREQUIREHTML', 1);
define('NOREQUIREAJAX', 1);

// Load Dolibarr environment
$res = 0;
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/factureligne.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.ligne.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/bank/class/account.class.php';

// Translation
$langs->loadLangs(array('easyback@easyback', 'bills', 'payments', 'stocks', 'banks', 'errors'));

$facid = GETPOSTINT('facid');
$element = GETPOST('element', 'alpha');
$action = GETPOST('action', 'aZ09');
$emode = GETPOST('mode', 'alpha');                // 'partial' (invoice card) | 'total' (card total / POS)
$elineids = GETPOST('lineid', 'array');
$eqtys = GETPOST('qty', 'array');
$idwarehouse = GETPOSTINT('idwarehouse');
$creditnote_id = GETPOSTINT('creditnote_id');
$token = GETPOST('token', 'aZ09');
$epopup = GETPOST('popup', 'alpha');              // ''/'dialog' = invoice card, 'colorbox' = TakePOS
$enoreturnstock = GETPOSTINT('noreturnstock');    // TakePOS terminal with stock change disabled
$eposterminal = GETPOST('posterminal', 'aZ09');   // TakePOS terminal (return made from the POS)

// Mode: explicit, or inferred (a line selection means a partial return).
if ($emode != 'partial' && $emode != 'total') {
	$emode = (is_array($elineids) && count($elineids) > 0) ? 'partial' : 'total';
}
$ispartial = ($emode == 'partial');

// Security
if (!isModEnabled('easyback')) {
	accessforbidden('Module not enabled');
}
global $user;

// CSRF check when creating/validating (token comes from the invoice card page)
if (!empty($conf->global->MAIN_SECURITY_CSRF_WITH_TOKEN) && !empty($token) && $token != currentToken()) {
	accessforbidden('Invalid token');
}

$isSupplier = ($element == 'facture_fourn' || $element == 'invoice_supplier');

// Stock reintegration. When the return comes from the POS, mirror the terminal
// setup (CASHDESK_NO_DECREASE_STOCK): if the sale did not change stock, the
// return must not change it either.
$estockallowed = (bool) getDolGlobalInt('EASYBACK_REINTEGRO_STOCK') && empty($enoreturnstock);

// Permissions: replicate the native card.php logic (create + validate)
if ($isSupplier) {
	$usercancreate = ($user->hasRight('fournisseur', 'facture', 'creer') || $user->hasRight('supplier_invoice', 'creer'));
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('fournisseur', 'supplier_invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		accessforbidden('Not enough permissions');
	}
} else {
	$usercancreate = $user->hasRight('facture', 'creer');
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('facture', 'invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		accessforbidden('Not enough permissions');
	}
}

$error = 0;
$errmsg = '';
$epayments = array();
$alreadyreturned = 0;
$emonto_devolver = 0;

$needwarehouse = 0;
$ewarehouse_array = array();

$formproduct = new FormProduct($db);

/**
 * Helper: create the credit note (draft) from the source invoice + marked lines.
 *
 * @param DoliDB  $db            Database handler
 * @param User    $user          User
 * @param bool    $isSupplier    True for supplier invoice, false for customer
 * @param int     $facid         Source invoice id
 * @param int[]   $lineids_arr   Selected line ids
 * @param mixed[] $qtys_arr      Quantities keyed by line id
 * @param string  $posterminal   POS terminal (empty for a backoffice return)
 * @param string  $errmsg        Output error message
 * @return int                   Credit note id or 0 on error
 */
function easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, $posterminal, &$errmsg)
{
	global $langs;

	$cnid = 0;

	if ($isSupplier) {
		$src = new FactureFournisseur($db);
		if ($src->fetch($facid) <= 0) {
			$errmsg = $src->error;
			return 0;
		}
		$src->fetch_lines();

		$cn = new FactureFournisseur($db);
		$cn->socid = $src->socid;
		// ref_supplier must be unique for (ref_supplier, fk_soc, entity). We can't use '' for a credit
		// note when the source invoice also has an empty ref_supplier (uk_facture_fourn_ref_supplier).
		// The native flow uses "CopyOf". We build a readable ref based on the unique source invoice ref,
		// with an incremental suffix so revisits don't collide with a previous credit note.
		$cn->ref_supplier = easyback_make_unique_ref_supplier($db, $langs->trans('EasyBackDevolucion').' '.$src->ref, $src->socid);
		$cn->type = FactureFournisseur::TYPE_CREDIT_NOTE;
		$cn->fk_facture_source = $src->id;
		$cn->cond_reglement_id = 0;
		$cn->mode_reglement_id = $src->mode_reglement_id;
		$cn->fk_account = $src->fk_account;
		$cn->date = dol_now();
		// Keep the same currency/rate as the source invoice so the bank reversal
		// respects the invoice rate (multicurrency) when registering the payment.
		$cn->multicurrency_code = $src->multicurrency_code;
		$cn->multicurrency_tx = $src->multicurrency_tx;

		$cnid = $cn->create($user);
		if ($cnid < 0) {
			$errmsg = $cn->error;
			return 0;
		}
		$cn->id = $cnid;

		foreach ($lineids_arr as $lineid) {
			$lineid = (int) $lineid;
			$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
			if ($qty <= 0) { continue; }

			$sl = new SupplierInvoiceLine($db);
			if ($sl->fetch($lineid) <= 0) { continue; }

			$cn->addline(
				$sl->desc,
				$sl->subprice,
				price2num($sl->tva_tx, 'MS'),
				$sl->localtax1_tx,
				$sl->localtax2_tx,
				$qty,
				$sl->fk_product,
				$sl->remise_percent,
				$sl->date_start,
				$sl->date_end,
				$sl->fk_code_ventilation,
				$sl->info_bits,
				'HT',
				$sl->product_type,
				-1,
				0,
				array(),
				$sl->fk_unit,
				$sl->origin_id,
				0,
				$sl->ref_supplier,
				$sl->special_code,
				$sl->fk_parent_line,
				$sl->fk_remise_except
			);
		}

		$cn->fetch($cnid);
		$cn->add_object_linked('invoice_supplier', $src->id);
		$cn->fetch($cnid);
	} else {
		$src = new Facture($db);
		if ($src->fetch($facid) <= 0) {
			$errmsg = $src->error;
			return 0;
		}
		$src->fetch_lines();

		$cn = new Facture($db);
		$cn->socid = $src->socid;
		$cn->type = Facture::TYPE_CREDIT_NOTE;
		$cn->fk_facture_source = $src->id;
		$cn->date = dol_now();
		// A return made from the TakePOS is marked with its origin (module + terminal)
		// so the POS cash close can attribute it to that terminal. Returns made from the
		// backoffice (partial or total) stay unmarked (they are not part of the POS transactions).
		if (!empty($posterminal)) {
			$cn->module_source = 'easyback';
			$cn->pos_source = $posterminal;
		}
		$cn->cond_reglement_id = 0;
		$cn->mode_reglement_id = $src->mode_reglement_id;
		$cn->fk_account = $src->fk_account;
		// Keep the same currency/rate as the source invoice so the bank reversal
		// respects the invoice rate (multicurrency) when registering the payment.
		$cn->multicurrency_code = $src->multicurrency_code;
		$cn->multicurrency_tx = $src->multicurrency_tx;

		$cnid = $cn->create($user);
		if ($cnid < 0) {
			$errmsg = $cn->error;
			return 0;
		}
		$cn->id = $cnid;

		foreach ($lineids_arr as $lineid) {
			$lineid = (int) $lineid;
			$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
			if ($qty <= 0) { continue; }

			$sl = new FactureLigne($db);
			if ($sl->fetch($lineid) <= 0) { continue; }

			$cn->addline(
				$sl->desc,
				$sl->subprice,
				$qty,
				price2num($sl->tva_tx, 'MS'),
				$sl->localtax1_tx,
				$sl->localtax2_tx,
				$sl->fk_product,
				$sl->remise_percent,
				$sl->date_start,
				$sl->date_end,
				$sl->fk_code_ventilation,
				$sl->info_bits,
				$sl->fk_remise_except,
				'HT',
				0,
				$sl->product_type,
				-1,
				$sl->special_code,
				$sl->origin,
				$sl->origin_id,
				$sl->fk_parent_line,
				null,
				0,                      // pa_ht
				'',                     // label (deprecated)
				array(),                // array_options
				100,                    // situation_percent
				0,                      // fk_prev_id
				$sl->fk_unit,           // fk_unit
				$sl->pu_ht_devise,      // pu_ht_devise
				$sl->ref_ext            // ref_ext
			);
		}

		$cn->fetch($cnid);
		$cn->add_object_linked('facture', $src->id);
		$cn->fetch($cnid);
	}

	return $cnid;
}

/**
 * Build a unique ref_supplier for a supplier credit note, appending an
 * incremental suffix when the base value already exists for the same supplier
 * (to respect the uk_facture_fourn_ref_supplier unique index).
 *
 * @param DoliDB $db       Database handler
 * @param string $base     Base reference (e.g. "Devolución <ref>")
 * @param int    $socid    Supplier id
 * @return string          Unique ref_supplier
 */
function easyback_make_unique_ref_supplier($db, $base, $socid)
{
	$base = trim($base);
	$candidate = $base;
	$i = 1;
	while (true) {
		$sql = "SELECT COUNT(*) as n FROM ".$db->prefix()."facture_fourn WHERE ref_supplier = '".$db->escape($candidate)."' AND fk_soc = ".((int) $socid);
		$resql = $db->query($sql);
		$n = 0;
		if ($resql && ($obj = $db->fetch_object($resql))) {
			$n = (int) $obj->n;
		}
		if ($n == 0) {
			return $candidate;
		}
		$i++;
		$candidate = $base.' ('.($i - 1).')';
	}
}

/**
 * Find any credit note already linked to a source invoice, so the popup
 * reuses it instead of creating a duplicate (which collides on the unique
 * ref / ref_supplier indexes). A draft note is rebuilt with the new
 * quantities; an already validated note means the return was processed.
 *
 * @param DoliDB $db        Database handler
 * @param bool   $isSupplier True for supplier invoice, false for customer
 * @param int    $facid     Source invoice id
 * @return int              Credit note id or 0 if none found
 */
function easyback_find_existing_creditnote($db, $isSupplier, $facid)
{
	$table = $isSupplier ? 'facture_fourn' : 'facture';
	$sql = "SELECT rowid FROM ".$db->prefix().$table." WHERE fk_facture_source = ".((int) $facid)." AND entity IN (".getEntity($table).") ORDER BY rowid LIMIT 1";
	$resql = $db->query($sql);
	if ($resql) {
		$obj = $db->fetch_object($resql);
		if ($obj) {
			return (int) $obj->rowid;
		}
	}
	return 0;
}

/**
 * Get ALL lines of the source invoice with their full quantities, for a total
 * return (no line/qty selection).
 *
 * @param DoliDB $db          Database handler
 * @param bool   $isSupplier  True for supplier invoice, false for customer
 * @param int    $facid       Source invoice id
 * @return array<int,float>   Map lineid => quantity
 */
function easyback_get_all_lines_qty($db, $isSupplier, $facid)
{
	$src = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	if ($src->fetch($facid) <= 0) {
		return array();
	}
	$src->fetch_lines();

	$tmp = array();
	foreach ($src->lines as $line) {
		$qty = price2num($line->qty, 'MS');
		if ($qty <= 0) {
			continue;
		}
		$tmp[(int) $line->id] = $qty;
	}

	return $tmp;
}

/**
 * Calculate the TTC amount of what is actually returned from the source
 * invoice, based on the marked lines and their quantities. Used only in partial
 * mode when the credit note is already validated (not rebuildable), so the
 * bank reversal never exceeds what was really returned in this attempt.
 *
 * @param DoliDB $db          Database handler
 * @param bool   $isSupplier  True for supplier invoice, false for customer
 * @param int    $facid       Source invoice id
 * @param array  $lineids_arr Selected line ids
 * @param array  $qtys_arr    Quantities keyed by line id
 * @return float              TTC amount of the returned lines (absolute)
 */
function easyback_calcular_monto_devolucion($db, $isSupplier, $facid, $lineids_arr, $qtys_arr)
{
	$src = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	if ($src->fetch($facid) <= 0) {
		return 0;
	}
	$src->fetch_lines();

	$total_ttc = 0;
	foreach ($lineids_arr as $lineid) {
		$lineid = (int) $lineid;
		$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
		if ($qty <= 0) {
			continue;
		}

		foreach ($src->lines as $line) {
			if ((int) $line->id !== $lineid) {
				continue;
			}
			// Work in the invoice currency (multicurrency) so the reversal
			// amount matches the currency of the bank account at the invoice rate.
			$mc_subprice = (!isset($line->multicurrency_subprice) || $line->multicurrency_subprice === '' || $line->multicurrency_subprice == null) ? $line->subprice : $line->multicurrency_subprice;
			$ht = price2num($mc_subprice, 'MT') * $qty * (1 - price2num($line->remise_percent, 'MU') / 100);
			$tva = $ht * price2num($line->tva_tx, 'MU') / 100;
			$total_ttc += $ht + $tva;
		}
	}

	return abs(price2num($total_ttc, 'MT'));
}

// Lines to return: all the invoice (total) or only the selected ones (partial).
if ($ispartial) {
	// Sanitize the selection against the real invoice lines.
	$ealllines = easyback_get_all_lines_qty($db, $isSupplier, $facid);
	$elines_qty = array();
	if (is_array($elineids)) {
		foreach ($elineids as $elineid) {
			$elineid = (int) $elineid;
			if (!isset($ealllines[$elineid])) {
				continue; // Line does not belong to this invoice.
			}
			$eq = (isset($eqtys[$elineid]) && $eqtys[$elineid] !== '') ? price2num($eqtys[$elineid], 'MS') : $ealllines[$elineid];
			if ($eq <= 0) {
				continue;
			}
			if ($eq > $ealllines[$elineid]) {
				$eq = $ealllines[$elineid]; // Never more than the invoiced quantity.
			}
			$elines_qty[$elineid] = $eq;
		}
	}
} else {
	$elines_qty = easyback_get_all_lines_qty($db, $isSupplier, $facid);
}
$lineids_arr = array_keys($elines_qty);
$qtys_arr = $elines_qty;

if (count($lineids_arr) <= 0) {
	$error++;
	$errmsg = $ispartial ? $langs->trans('EasyBackErrorSinLineas') : $langs->trans('ErrorObjectMustHaveLinesToBeValidated', '');
}

// If no credit note id yet, look for one already linked to the source invoice.
if ($creditnote_id <= 0) {
	$creditnote_id = easyback_find_existing_creditnote($db, $isSupplier, $facid);
}

if ($creditnote_id > 0 && !$error) {
	$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$ecn->fetch($creditnote_id);

	if ($ecn->status > 0 && !$ispartial) {
		// Total mode, already validated: the whole invoice was already returned.
		$alreadyreturned = $creditnote_id;
	} elseif ($ecn->status > 0 && $ispartial) {
		// Partial mode: reuse the validated credit note as-is; the refund amount
		// is recalculated below from the lines selected now.
	} else {
		// Draft: rebuild it with the selected lines so it reflects this return.
		$db->begin();
		$delresult = $ecn->delete($user);
		if ($delresult < 0) {
			$error++;
			$errmsg = $ecn->error;
			$db->rollback();
		} else {
			$creditnote_id = easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, $eposterminal, $errmsg);
			if ($creditnote_id <= 0) {
				$error++;
				$db->rollback();
			} else {
				$db->commit();
			}
		}
	}
} elseif (!$error) {
	$db->begin();
	$creditnote_id = easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, $eposterminal, $errmsg);
	if ($creditnote_id <= 0) {
		$error++;
		$db->rollback();
	} else {
		$db->commit();
	}
}

// Determine stock / warehouse needs
if ($creditnote_id > 0 && !$error && !$alreadyreturned && getDolGlobalString('STOCK_CALCULATE_ON_BILL') && $estockallowed) {
	$esrc = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$esrc->fetch($facid);
	$hasProducts = method_exists($esrc, 'hasProductsOrServices') ? $esrc->hasProductsOrServices(2) : 0;
	if ($hasProducts) {
		$ewarehouse = new Entrepot($db);
		$ewarehouse_array = $ewarehouse->list_array();
		if (count($ewarehouse_array) == 1) {
			$idwarehouse = (int) key($ewarehouse_array); // single warehouse: use it directly
		} elseif (count($ewarehouse_array) > 1 && empty($idwarehouse)) {
			$needwarehouse = 1; // several warehouses: ask (unless the caller, e.g. the POS, gave one)
		}
	}
}

// Validate action
if ($action == 'validate' && $creditnote_id > 0 && !$error && !$alreadyreturned) {
	if ($needwarehouse && $idwarehouse <= 0) {
		// The stock must be returned, so a warehouse is mandatory.
		$error++;
		$errmsg = $langs->trans('EasyBackErrorAlmacen');
	} else {
		$db->begin();
		$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
		$ecn->fetch($creditnote_id);
		// Only move stock if EASYBACK_REINTEGRO_STOCK is on. validate() moves stock
		// only when $idwarehouse > 0, so pass 0 to disable stock movement.
		$ewh = $estockallowed ? $idwarehouse : 0;
		$eresult = $ecn->validate($user, '', $ewh);
		if ($eresult < 0) {
			$error++;
			$errmsg = $ecn->error;
			$db->rollback();
		} else {
			$db->commit();
			$needwarehouse = 0; // Once validated, no longer ask for warehouse
		}
	}
}

// Auto-validate if not requested warehouse
if ($creditnote_id > 0 && !$error && !$alreadyreturned && getDolGlobalInt('EASYBACK_AUTO_VALIDAR') && !$needwarehouse) {
	$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$ecn->fetch($creditnote_id);
	if ($ecn->status == 0) { // draft only
		$db->begin();
		$ewh = $estockallowed ? $idwarehouse : 0;
		$eresult = $ecn->validate($user, '', $ewh);
		if ($eresult < 0) {
			$error++;
			$errmsg = $ecn->error;
			$db->rollback();
		} else {
			$db->commit();
		}
	}
}

// Fetch credit note lines/total and the payments of the source invoice.
$ecnlines = array();
$ecurrencycode = $conf->currency;
if ($creditnote_id > 0 && !$error && !$alreadyreturned) {
	$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$ecn->fetch($creditnote_id);
	$ecn->fetch_lines();
	$ecnlines = $ecn->lines;
	$ecurrencycode = $ecn->multicurrency_code ? $ecn->multicurrency_code : $conf->currency;

	$esrc = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$esrc->fetch($facid);
	// mode = 1 => real payments only (not credit notes/discounts/deposits),
	// listed in the invoice currency so the reversal keeps the invoice rate.
	$epayments = $esrc->getListOfPayments('', 1, 1);

	// Money to refund (partial mode), in the credit note (invoice) currency.
	if ($ispartial) {
		if ($ecn->status > 0) {
			// Validated: recalculate from the lines selected now.
			$emonto_devolver = easyback_calcular_monto_devolucion($db, $isSupplier, $facid, $lineids_arr, $qtys_arr);
		} else {
			$emonto_devolver = !empty($ecn->multicurrency_total_ttc) ? abs((float) $ecn->multicurrency_total_ttc) : abs((float) $ecn->total_ttc);
		}
	}
}

$etotal_pagos = 0;
foreach ($epayments as $epayment) {
	$etotal_pagos += abs((float) $epayment['amount']);
}

llxHeader('', $langs->trans('EasyBackProcesarDevolucion'));

print '<div style="padding:10px;">';
print '<script>
// Close/reload the parent page: supports the invoice card (jQuery UI dialog) and
// the TakePOS (colorbox iframe).
function easybackCloseParent() {
    if (parent.$ && parent.$.colorbox) {
        parent.$.colorbox.close();
    } else if (parent.jQuery && parent.jQuery("#idfordialogeasyback").length) {
        parent.jQuery("#idfordialogeasyback").dialog("close");
    }
}
function easybackReloadParent() {
    if (parent.$ && parent.$.colorbox) {
        parent.$.colorbox.close();
        if (typeof parent.Refresh === "function") { parent.Refresh(); }
    } else if (parent.jQuery && parent.jQuery("#idfordialogeasyback").length) {
        parent.location.reload();
    }
}
</script>';
print '<h3>'.($ispartial ? $langs->trans('EasyBackDevolucion') : $langs->trans('EasyBackDevolucionTotal')).'</h3>';

if ($alreadyreturned) {
	$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$ecn->fetch($alreadyreturned);
	$enotaUrl = DOL_URL_ROOT.($isSupplier ? '/fourn/facture/card.php' : '/compta/facture/card.php').'?facid='.((int) $alreadyreturned);

	print '<div class="warning">'.$langs->trans('EasyBackYaDevuelta', $ecn->ref).'</div>';
	print '<br>';
	if ($epopup != 'colorbox') {
		print '<a class="butAction" href="#" onclick="parent.window.location.href = \''.dol_escape_js($enotaUrl).'\'; return false;">'.$langs->trans('EasyBackVerNota').'</a> &nbsp; ';
	}
	print '<a class="butActionRefused" href="#" onclick="easybackCloseParent(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';
} elseif ($error) {
	print '<div class="error">'.$langs->trans('Error').' : '.dol_escape_htmltag($errmsg).'</div>';
	if ($needwarehouse) {
		// Show the warehouse form again so the operator can pick one and retry.
		print '<h4>'.$langs->trans('EasyBackSelectWarehouse').'</h4>';
		print '<form method="post" action="'.$_SERVER['PHP_SELF'].'">';
		print '<input type="hidden" name="token" value="'.currentToken().'">';
		print '<input type="hidden" name="action" value="validate">';
		print '<input type="hidden" name="mode" value="'.dol_escape_js($emode).'">';
		print '<input type="hidden" name="element" value="'.dol_escape_js($element).'">';
		print '<input type="hidden" name="facid" value="'.(int) $facid.'">';
		print '<input type="hidden" name="creditnote_id" value="'.(int) $creditnote_id.'">';
		print $formproduct->selectWarehouses(0, 'idwarehouse', '', 1, 0, '', 0);
		print '<br><br>';
		print '<button class="butAction" type="submit">'.$langs->trans('EasyBackValidarAbono').'</button>';
		print '</form>';
	}
	print '<a class="butActionRefused" href="#" onclick="easybackCloseParent(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';
} else {
	$ecnref = '';
	if ($creditnote_id > 0) {
		$ecn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
		$ecn->fetch($creditnote_id);
		$ecnref = $ecn->ref;
	}
	// URL of the created credit note.
	$enotaUrl = DOL_URL_ROOT.($isSupplier ? '/fourn/facture/card.php' : '/compta/facture/card.php').'?facid='.((int) $creditnote_id);

	print '<div class="ok">'.$langs->trans('EasyBackAbonoCreado', $ecnref).'</div>';
	print '<br>';

	// If warehouse confirmation is needed
	if ($needwarehouse) {
		print '<h4>'.$langs->trans('EasyBackSelectWarehouse').'</h4>';
		print '<form method="post" action="'.$_SERVER['PHP_SELF'].'">';
		print '<input type="hidden" name="token" value="'.currentToken().'">';
		print '<input type="hidden" name="action" value="validate">';
		print '<input type="hidden" name="mode" value="'.dol_escape_js($emode).'">';
		print '<input type="hidden" name="element" value="'.dol_escape_js($element).'">';
		print '<input type="hidden" name="facid" value="'.(int) $facid.'">';
		print '<input type="hidden" name="creditnote_id" value="'.(int) $creditnote_id.'">';
		print $formproduct->selectWarehouses(0, 'idwarehouse', '', 1, 0, '', 0);
		print '<br><br>';
		print '<button class="butAction" type="submit">'.$langs->trans('EasyBackValidarAbono').'</button>';
		print '</form>';

		print '</div>';
		llxFooter();
		$db->close();
		exit;
	}

	// Summary of the returned lines (read only).
	print '<h4>'.$langs->trans('EasyBackLineasDevueltas').'</h4>';
	if (count($ecnlines) > 0) {
		print '<table class="noborder centpercent">';
		print '<tr class="liste_titre">';
		print '<th>'.$langs->trans('Description').'</th>';
		print '<th class="right">'.$langs->trans('Qty').'</th>';
		print '<th class="right">'.$langs->trans('TotalTTC').'</th>';
		print '</tr>';
		foreach ($ecnlines as $eline) {
			print '<tr class="oddeven">';
			print '<td>'.dol_escape_htmltag((string) $eline->desc).'</td>';
			print '<td class="right">'.price2num($eline->qty, 'MS').'</td>';
			print '<td class="right">'.price(abs((float) $eline->total_ttc), 0, '', 1, -1, -1, $ecurrencycode).'</td>';
			print '</tr>';
		}
		print '</table>';
	}

	// Payments of the source invoice.
	print '<h4>'.$langs->trans('EasyBackPagosRealizados').'</h4>';

	if (count($epayments) > 0) {
		print '<table class="noborder centpercent">';
		print '<tr class="liste_titre">';
		if ($ispartial) {
			print '<th style="width:20px;"></th>';
		}
		print '<th>'.$langs->trans('Payment').'</th>';
		print '<th>'.$langs->trans('BankAccount').'</th>';
		print '<th class="right">'.$langs->trans('Amount').'</th>';
		print '<th class="right">'.$langs->trans('Date').'</th>';
		print '</tr>';
		foreach ($epayments as $epayment) {
			$eamount = abs((float) $epayment['amount']);
			$epaytype = $epayment['type'];
			// Resolve the bank account where this channel was originally paid, so
			// the reversal registers in the same bank (respects its currency).
			$ebanklabel = '';
			$ebankacctid = 0;
			if (!empty($epayment['fk_bank_line'])) {
				$ebankline = new AccountLine($db);
				if ($ebankline->fetch((int) $epayment['fk_bank_line']) > 0 && !empty($ebankline->fk_account)) {
					$ebankacctid = (int) $ebankline->fk_account;
					$ebankaccount = new Account($db);
					if ($ebankaccount->fetch($ebankacctid) > 0) {
						$ebanklabel = $ebankaccount->label;
					}
				}
			}
			print '<tr class="oddeven">';
			if ($ispartial) {
				print '<td><input type="checkbox" class="easyback-pay" name="easyback_payment[]" value="'.dol_escape_js($epaytype).'" data-amount="'.$eamount.'" data-type="'.dol_escape_js($epaytype).'" data-account="'.(int) $ebankacctid.'"></td>';
			}
			print '<td>'.$langs->trans('PaymentTypeShort'.$epaytype).'</td>';
			print '<td>'.($ebanklabel ? dol_escape_htmltag($ebanklabel) : '<span class="opacitymedium">-</span>').'</td>';
			print '<td class="right">'.price($eamount).' '.$ecurrencycode.'</td>';
			print '<td class="right">'.dol_print_date($db->jdate($epayment['date']), '%d/%m/%Y').'</td>';
			print '</tr>';
		}
		print '</table>';

		print '<div style="margin:12px 0;">';
		if ($ispartial) {
			print $langs->trans('EasyBackMontoDevolver').' : <b>'.price($emonto_devolver, 0, '', 1, -1, -1, $ecurrencycode).'</b> &nbsp; ';
			print $langs->trans('EasyBackReversoTot').' : <b id="easyback-sel-total">0 '.$ecurrencycode.'</b>';
		} else {
			print $langs->trans('EasyBackMontoDevolver').' : <b>'.price($etotal_pagos, 0, '', 1, -1, -1, $ecurrencycode).'</b>';
		}
		print '</div>';

		if ($epopup == 'colorbox') {
			print '<div class="error" id="easyback-error-box" style="display:none;"></div>';
		}

		$eajaxurl = dol_buildpath('/easyback/return_ajax.php', 1);
		print '<button class="butAction" id="easyback-reverse-btn" onclick="EasyBackReverse()">'.($ispartial ? $langs->trans('EasyBackProcesarReverso') : $langs->trans('EasyBackProcesarDevolucion')).'</button> &nbsp; ';
		// From the POS we must not navigate the parent page away from the POS.
		if ($epopup != 'colorbox') {
			print '<a class="butAction" href="#" onclick="parent.window.location.href = \''.dol_escape_js($enotaUrl).'\'; return false;">'.$langs->trans('EasyBackVerNota').'</a> &nbsp; ';
		}
		print '<a class="butActionRefused" href="#" onclick="easybackReloadParent(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';

		$esuccessmsg = dol_escape_js($langs->trans('EasyBackExito'));
		if ($epopup == 'colorbox') {
			// POS: show the error inside the popup (the colorbox overlay would hide
			// a dialog of the parent) and notify on the POS after closing.
			$eonerror = '$("#easyback-error-box").html(resp.error).show();';
			$eonsuccess = 'parent.EasyBackPosNotify("'.dol_escape_js($langs->trans('EasyBackDevolucionTotal')).'", "'.$esuccessmsg.'");';
		} else {
			$eonerror = 'parent.easybackNotification(easybackAviso, resp.error);';
			$eonsuccess = 'parent.easybackNotification(easybackProcesar, "'.$esuccessmsg.'", { url: easybackNotaUrl });';
		}

		if ($ispartial) {
			// Partial: the operator marks which payment channels to reverse; the
			// equivalent money is prorated across them by their original weight.
			print '<script>
var easybackAjaxUrl = "'.dol_escape_js($eajaxurl).'";
var easybackCreditnoteId = "'.(int) $creditnote_id.'";
var easybackFacid = "'.(int) $facid.'";
var easybackElement = "'.dol_escape_js($isSupplier ? 'facture_fourn' : 'facture').'";
var easybackToken = "'.dol_escape_js(currentToken()).'";
var easybackMonto = "'.price2num($emonto_devolver, 'MT').'";
var easybackCurrency = "'.dol_escape_js($ecurrencycode).'";
var easybackNotaUrl = "'.dol_escape_js($enotaUrl).'";
var easybackAviso = "'.dol_escape_js($langs->trans('EasyBackAviso')).'";
var easybackProcesar = "'.dol_escape_js($langs->trans('EasyBackDevolucion')).'";
function EasyBackUpdateSelTotal() {
    var total = 0;
    if ($("input.easyback-pay:checked").length > 0) { total = parseFloat(easybackMonto) || 0; }
    $("#easyback-sel-total").text(total.toFixed(2) + " " + easybackCurrency);
}
$(function() {
    $("input.easyback-pay").on("change", EasyBackUpdateSelTotal);
    EasyBackUpdateSelTotal();
});
function EasyBackReverse() {
    var payments = [];
    $("input.easyback-pay:checked").each(function() {
        payments.push({ type: $(this).attr("data-type"), weight: parseFloat($(this).attr("data-amount")), account: parseInt($(this).attr("data-account")) || 0 });
    });
    if (!payments.length) { parent.easybackNotification(easybackAviso, "'.dol_escape_js($langs->trans('EasyBackErrorMarcaPago')).'"); return; }
    var edata = { token: easybackToken, creditnote_id: easybackCreditnoteId, facid: easybackFacid, element: easybackElement, monto_total: easybackMonto, payments: JSON.stringify(payments) };
    $("#easyback-reverse-btn").prop("disabled", true);
    $.post(easybackAjaxUrl, edata, function(resp) {
        if (resp.error) {
            $("#easyback-reverse-btn").prop("disabled", false);
            '.$eonerror.'
        } else {
            '.$eonsuccess.'
        }
    }, "json");
}
</script>';
		} else {
			print '<script>
var easybackAjaxUrl = "'.dol_escape_js($eajaxurl).'";
var easybackCreditnoteId = "'.(int) $creditnote_id.'";
var easybackFacid = "'.(int) $facid.'";
var easybackElement = "'.dol_escape_js($isSupplier ? 'facture_fourn' : 'facture').'";
var easybackToken = "'.dol_escape_js(currentToken()).'";
var easybackCurrency = "'.dol_escape_js($ecurrencycode).'";
var easybackNotaUrl = "'.dol_escape_js($enotaUrl).'";
var easybackAviso = "'.dol_escape_js($langs->trans('EasyBackAviso')).'";
var easybackProcesar = "'.dol_escape_js($langs->trans('EasyBackDevolucionTotal')).'";
function EasyBackReverse() {
    var edata = { token: easybackToken, creditnote_id: easybackCreditnoteId, facid: easybackFacid, element: easybackElement };
    $("#easyback-reverse-btn").prop("disabled", true);
    $.post(easybackAjaxUrl, edata, function(resp) {
        if (resp.error) {
            $("#easyback-reverse-btn").prop("disabled", false);
            '.$eonerror.'
        } else {
            '.$eonsuccess.'
        }
    }, "json");
}
</script>';
		}
	} else {
		print '<div class="opacitymedium">'.($ispartial ? $langs->trans('EasyBackSinPagos') : $langs->trans('EasyBackSinPagosTotal')).'</div>';
		if ($epopup != 'colorbox') {
			print '<a class="butAction" href="#" onclick="parent.window.location.href = \''.dol_escape_js($enotaUrl).'\'; return false;">'.$langs->trans('EasyBackVerNota').'</a> &nbsp; ';
		}
		print '<a class="butActionRefused" href="#" onclick="easybackReloadParent(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';
	}
}

print '</div>';

llxFooter();
$db->close();
