<?php
/* Copyright (C) 2026		SuperAdmin
 * Copyright (C) 2025       Frédéric France         <frederic.france@free.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    easyback/lib/easyback.lib.php
 * \ingroup easyback
 * \brief   Library files with common functions for EasyBack
 */

/**
 * List the credit notes of a source invoice: the drafts (an unfinished return,
 * rebuilt on the next attempt) or the validated ones (returns already done).
 * Abandoned credit notes are ignored.
 *
 * @param DoliDB $db         Database handler
 * @param bool   $isSupplier True for supplier invoice, false for customer
 * @param int    $facid      Source invoice id
 * @param bool   $draft      True for the drafts, false for the validated ones
 * @return int[]             Credit note ids, oldest first
 */
function easyback_get_creditnotes($db, $isSupplier, $facid, $draft)
{
	$table = $isSupplier ? 'facture_fourn' : 'facture';
	$sql = "SELECT rowid FROM ".$db->prefix().$table;
	$sql .= " WHERE fk_facture_source = ".((int) $facid)." AND type = 2";
	$sql .= " AND fk_statut ".($draft ? "= 0" : "IN (1, 2)");
	$sql .= " AND entity IN (".getEntity($table).")";
	$sql .= " ORDER BY rowid";

	$ids = array();
	$resql = $db->query($sql);
	if ($resql) {
		while ($obj = $db->fetch_object($resql)) {
			$ids[] = (int) $obj->rowid;
		}
	}
	return $ids;
}

/**
 * Prepare admin pages header
 *
 * @return array<array{string,string,string}>
 */
function easybackAdminPrepareHead()
{
	global $langs, $conf;

	// global $db;
	// $extrafields = new ExtraFields($db);
	// $extrafields->fetch_name_optionals_label('myobject');

	$langs->load("easyback@easyback");

	$h = 0;
	$head = array();

	$head[$h][0] = dolBuildUrl(dol_buildpath("/easyback/admin/setup.php", 1));
	$head[$h][1] = $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;

	/*
	$head[$h][0] = dolBuildUrl(dol_buildpath("/easyback/admin/myobject_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFields");
	$nbExtrafields = (isset($extrafields->attributes['myobject']['label']) && is_countable($extrafields->attributes['myobject']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafields';
	$h++;

	$head[$h][0] = dolBuildUrl(dol_buildpath("/easyback/admin/myobjectline_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFieldsLines");
	$nbExtrafields = (isset($extrafields->attributes['myobjectline']['label']) && is_countable($extrafields->attributes['myobjectline']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafieldsline';
	$h++;
	*/

	$head[$h][0] = dolBuildUrl(dol_buildpath("/easyback/admin/about.php", 1));
	$head[$h][1] = $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@easyback:/easyback/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@easyback:/easyback/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'easyback@easyback');

	complete_head_from_modules($conf, $langs, null, $head, $h, 'easyback@easyback', 'remove');

	return $head;
}
