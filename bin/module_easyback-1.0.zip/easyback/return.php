<?php
/* Copyright (C) 2026		Edgar Bustamante	<ebustamantep@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    easyback/return.php
 * \ingroup easyback
 * \brief   Popup to process a return: create + validate credit note, then
 *          show paid payments to run the bank reversal.
 */

define('NOTOKENRENEWAL', 1);
define('NOREQUIREMENU', 1);
define('NOREQUIREHTML', 1);
define('NOREQUIREAJAX', 1);

// Load Dolibarr environment
$res = 0;
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/factureligne.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.ligne.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/bank/class/account.class.php';

// Translation
$langs->loadLangs(array('easyback@easyback', 'bills', 'payments', 'stocks'));

$facid = GETPOSTINT('facid');
$element = GETPOST('element', 'alpha');
$action = GETPOST('action', 'aZ09');
$lineids = GETPOST('lineid', 'array');
$qtys = GETPOST('qty', 'array');
$idwarehouse = GETPOSTINT('idwarehouse');
$creditnote_id = GETPOSTINT('creditnote_id');
$token = GETPOST('token', 'aZ09');

// Security
if (!isModEnabled('easyback')) {
	accessforbidden('Module not enabled');
}
global $user;

// CSRF check when creating/validating (token comes from the invoice card page)
if (!empty($conf->global->MAIN_SECURITY_CSRF_WITH_TOKEN) && !empty($token) && $token != currentToken()) {
	accessforbidden('Invalid token');
}

$isSupplier = ($element == 'facture_fourn' || $element == 'invoice_supplier');

// Permissions: replicate the native card.php logic (create + validate)
if ($isSupplier) {
	$usercancreate = ($user->hasRight('fournisseur', 'facture', 'creer') || $user->hasRight('supplier_invoice', 'creer'));
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('fournisseur', 'supplier_invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		accessforbidden('Not enough permissions');
	}
} else {
	$usercancreate = $user->hasRight('facture', 'creer');
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('facture', 'invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		accessforbidden('Not enough permissions');
	}
}

$error = 0;
$errmsg = '';
$creditnote_total = 0;
$payments = array();

$needwarehouse = 0;
$warehouse_array = array();

$formproduct = new FormProduct($db);

/**
 * Helper: create the credit note (draft) from the source invoice + marked lines.
 *
 * @return int credit note id or 0 on error
 */
function easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, &$errmsg)
{
	global $langs;

	$cnid = 0;

	if ($isSupplier) {
		$src = new FactureFournisseur($db);
		if ($src->fetch($facid) <= 0) {
			$errmsg = $src->error;
			return 0;
		}
		$src->fetch_lines();

		$cn = new FactureFournisseur($db);
		$cn->socid = $src->socid;
		// ref_supplier must be unique for (ref_supplier, fk_soc, entity). We can't use '' for a credit
		// note when the source invoice also has an empty ref_supplier (uk_facture_fourn_ref_supplier).
		// The native flow uses "CopyOf". We build a readable ref based on the unique source invoice ref,
		// with an incremental suffix so revisits don't collide with a previous credit note.
		$cn->ref_supplier = easyback_make_unique_ref_supplier($db, $langs->trans('EasyBackDevolucion').' '.$src->ref, $src->socid);
		$cn->type = FactureFournisseur::TYPE_CREDIT_NOTE;
		$cn->fk_facture_source = $src->id;
		$cn->cond_reglement_id = 0;
		$cn->mode_reglement_id = $src->mode_reglement_id;
		$cn->fk_account = $src->fk_account;
		$cn->date = dol_now();
		// Keep the same currency/rate as the source invoice so the bank reversal
		// respects the invoice rate (multicurrency) when registering the payment.
		$cn->multicurrency_code = $src->multicurrency_code;
		$cn->multicurrency_tx = $src->multicurrency_tx;

		$cnid = $cn->create($user);
		if ($cnid < 0) {
			$errmsg = $cn->error;
			return 0;
		}
		$cn->id = $cnid;

		foreach ($lineids_arr as $lineid) {
			$lineid = (int) $lineid;
			$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
			if ($qty <= 0) { continue; }

			$sl = new SupplierInvoiceLine($db);
			if ($sl->fetch($lineid) <= 0) { continue; }

			$cn->addline(
				$sl->desc,
				$sl->subprice,
				price2num($sl->tva_tx, 'MS'),
				$sl->localtax1_tx,
				$sl->localtax2_tx,
				$qty,
				$sl->fk_product,
				$sl->remise_percent,
				$sl->date_start,
				$sl->date_end,
				$sl->fk_code_ventilation,
				$sl->info_bits,
				'HT',
				$sl->product_type,
				-1,
				0,
				array(),
				$sl->fk_unit,
				$sl->origin_id,
				0,
				$sl->ref_supplier,
				$sl->special_code,
				$sl->fk_parent_line,
				$sl->fk_remise_except
			);
		}

		$cn->fetch($cnid);
		$cn->add_object_linked('invoice_supplier', $src->id);
		$cn->fetch($cnid);
	} else {
		$src = new Facture($db);
		if ($src->fetch($facid) <= 0) {
			$errmsg = $src->error;
			return 0;
		}
		$src->fetch_lines();

		$cn = new Facture($db);
		$cn->socid = $src->socid;
		$cn->type = Facture::TYPE_CREDIT_NOTE;
		$cn->fk_facture_source = $src->id;
		$cn->date = dol_now();
		$cn->cond_reglement_id = 0;
		$cn->mode_reglement_id = $src->mode_reglement_id;
		$cn->fk_account = $src->fk_account;
		// Keep the same currency/rate as the source invoice so the bank reversal
		// respects the invoice rate (multicurrency) when registering the payment.
		$cn->multicurrency_code = $src->multicurrency_code;
		$cn->multicurrency_tx = $src->multicurrency_tx;

		$cnid = $cn->create($user);
		if ($cnid < 0) {
			$errmsg = $cn->error;
			return 0;
		}
		$cn->id = $cnid;

		foreach ($lineids_arr as $lineid) {
			$lineid = (int) $lineid;
			$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
			if ($qty <= 0) { continue; }

			$sl = new FactureLigne($db);
			if ($sl->fetch($lineid) <= 0) { continue; }

			$cn->addline(
				$sl->desc,
				$sl->subprice,
				$qty,
				price2num($sl->tva_tx, 'MS'),
				$sl->localtax1_tx,
				$sl->localtax2_tx,
				$sl->fk_product,
				$sl->remise_percent,
				$sl->date_start,
				$sl->date_end,
				$sl->fk_code_ventilation,
				$sl->info_bits,
				$sl->fk_remise_except,
				'HT',
				0,
				$sl->product_type,
				-1,
				$sl->special_code,
				$sl->origin,
				$sl->origin_id,
				$sl->fk_parent_line,
				null,
				0,                      // pa_ht
				'',                     // label (deprecated)
				array(),                // array_options
				100,                    // situation_percent
				0,                      // fk_prev_id
				$sl->fk_unit,           // fk_unit
				$sl->pu_ht_devise,      // pu_ht_devise
				$sl->ref_ext            // ref_ext
			);
		}

		$cn->fetch($cnid);
		$cn->add_object_linked('facture', $src->id);
		$cn->fetch($cnid);
	}

	return $cnid;
}

/**
 * Build a unique ref_supplier for a supplier credit note, appending an
 * incremental suffix when the base value already exists for the same supplier
 * (to respect the uk_facture_fourn_ref_supplier unique index).
 *
 * @param DoliDB $db       Database handler
 * @param string $base     Base reference (e.g. "Devolución <ref>")
 * @param int    $socid    Supplier id
 * @return string          Unique ref_supplier
 */
function easyback_make_unique_ref_supplier($db, $base, $socid)
{
	$base = trim($base);
	$candidate = $base;
	$i = 1;
	while (true) {
		$sql = "SELECT COUNT(*) as n FROM ".$db->prefix()."facture_fourn WHERE ref_supplier = '".$db->escape($candidate)."' AND fk_soc = ".((int) $socid);
		$resql = $db->query($sql);
		$n = 0;
		if ($resql && ($obj = $db->fetch_object($resql))) {
			$n = (int) $obj->n;
		}
		if ($n == 0) {
			return $candidate;
		}
		$i++;
		$candidate = $base.' ('.($i - 1).')';
	}
}

/**
 * Find any credit note already linked to a source invoice, so the popup
 * reuses it instead of creating a duplicate (which collides on the unique
 * ref / ref_supplier indexes). A draft note is rebuilt with the new
 * quantities; an already validated note means the return was processed.
 *
 * @param DoliDB $db        Database handler
 * @param bool   $isSupplier True for supplier invoice, false for customer
 * @param int    $facid     Source invoice id
 * @return int              Credit note id or 0 if none found
 */
function easyback_find_existing_creditnote($db, $isSupplier, $facid)
{
	$table = $isSupplier ? 'facture_fourn' : 'facture';
	$sql = "SELECT rowid FROM ".$db->prefix().$table." WHERE fk_facture_source = ".((int) $facid)." AND entity IN (".getEntity($table).") ORDER BY rowid LIMIT 1";
	$resql = $db->query($sql);
	if ($resql) {
		$obj = $db->fetch_object($resql);
		if ($obj) {
			return (int) $obj->rowid;
		}
	}
	return 0;
}

/**
 * Calculate the TTC amount of what is actually returned from the source
 * invoice, based on the marked lines and their quantities. Used only as a
 * fallback when the credit note is already validated (not rebuildable), so the
 * bank reversal never exceeds what was really returned in this attempt.
 *
 * @param DoliDB $db          Database handler
 * @param bool   $isSupplier  True for supplier invoice, false for customer
 * @param int    $facid       Source invoice id
 * @param array  $lineids_arr Selected line ids
 * @param array  $qtys_arr    Quantities keyed by line id
 * @return float              TTC amount of the returned lines (absolute)
 */
function easyback_calcular_monto_devolucion($db, $isSupplier, $facid, $lineids_arr, $qtys_arr)
{
	$src = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	if ($src->fetch($facid) <= 0) {
		return 0;
	}
	$src->fetch_lines();

	$total_ttc = 0;
	foreach ($lineids_arr as $lineid) {
		$lineid = (int) $lineid;
		$qty = (isset($qtys_arr[$lineid]) && $qtys_arr[$lineid] !== '') ? price2num($qtys_arr[$lineid], 'MS') : 1;
		if ($qty <= 0) {
			continue;
		}

		foreach ($src->lines as $line) {
			if ((int) $line->id !== $lineid) {
				continue;
			}
			// Work in the invoice currency (multicurrency) so the reversal
			// amount matches the currency of the bank account at the invoice rate.
			$mc_subprice = (!isset($line->multicurrency_subprice) || $line->multicurrency_subprice === '' || $line->multicurrency_subprice == null) ? $line->subprice : $line->multicurrency_subprice;
			$ht = price2num($mc_subprice, 'MT') * $qty * (1 - price2num($line->remise_percent, 'MU') / 100);
			$tva = $ht * price2num($line->tva_tx, 'MU') / 100;
			$total_ttc += $ht + $tva;
		}
	}

	return abs(price2num($total_ttc, 'MT'));
}

// Create credit note (draft) if lineids posted and no creditnote_id provided yet
$lineids_arr = is_array($lineids) ? $lineids : array();
$qtys_arr = is_array($qtys) ? $qtys : array();

// If no credit note id yet, look for a DRAFT credit note linked to the source
// invoice. Reusing a draft (instead of duplicating) avoids the unique
// ref_supplier / ref collision.
if ($creditnote_id <= 0) {
	$creditnote_id = easyback_find_existing_creditnote($db, $isSupplier, $facid);
}

if ($creditnote_id > 0 && count($lineids_arr) > 0) {
	// There is an existing credit note for this source invoice.
	$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$cn->fetch($creditnote_id);
	if ($cn->status == 0) {
		// Draft: rebuild it with the new quantities so lines reflect the returned qty.
		$db->begin();
		$delresult = $cn->delete($user);
		if ($delresult < 0) {
			$error++;
			$errmsg = $cn->error;
			$db->rollback();
		} else {
			$creditnote_id = easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, $errmsg);
			if ($creditnote_id <= 0) {
				$error++;
				$db->rollback();
			} else {
				$db->commit();
			}
		}
	}
	// If already validated, the return was processed: keep it as-is (we just
	// show its payments to reverse below).
} elseif ($creditnote_id <= 0 && count($lineids_arr) > 0) {
	$db->begin();
	$creditnote_id = easyback_create_credit_note($db, $user, $isSupplier, $facid, $lineids_arr, $qtys_arr, $errmsg);
	if ($creditnote_id <= 0) {
		$error++;
		$db->rollback();
	} else {
		$db->commit();
	}
}

// Amount to refund = what is really returned (credit note total). For an
// already validated credit note (reused from a previous attempt) we cannot
// rebuild its lines, so we recalculate from the lines/quantities marked now to
// avoid reversing more than what was actually returned in this attempt.
$monto_devolver = 0;
if ($creditnote_id > 0 && !$error) {
	$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$cn->fetch($creditnote_id);
	if ($cn->status > 0) {
		$monto_devolver = easyback_calcular_monto_devolucion($db, $isSupplier, $facid, $lineids_arr, $qtys_arr);
	} else {
		// Always in the invoice currency so the core converts to the bank currency.
		$monto_devolver = !empty($cn->multicurrency_total_ttc) ? abs((float) $cn->multicurrency_total_ttc) : abs((float) $cn->total_ttc);
	}
}
$reving = $monto_devolver;

// Determine stock / warehouse needs
if ($creditnote_id > 0 && getDolGlobalString('STOCK_CALCULATE_ON_BILL') && getDolGlobalInt('EASYBACK_REINTEGRO_STOCK')) {
	$src2 = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$src2->fetch($facid);
	$hasProducts = method_exists($src2, 'hasProductsOrServices') ? $src2->hasProductsOrServices(2) : 0;
	if ($hasProducts) {
		$warehouse = new Entrepot($db);
		$warehouse_array = $warehouse->list_array();
		if (count($warehouse_array) == 1) {
			$idwarehouse = (int) key($warehouse_array); // single warehouse: use it directly
		} elseif (count($warehouse_array) > 1) {
			$needwarehouse = 1;
		}
	}
}

// Validate action
if ($action == 'validate' && $creditnote_id > 0) {
	$db->begin();
	$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$cn->fetch($creditnote_id);
	// Only move stock if EASYBACK_REINTEGRO_STOCK is on. validate() moves stock
	// only when $idwarehouse > 0, so pass 0 to disable stock movement.
	$wh = getDolGlobalInt('EASYBACK_REINTEGRO_STOCK') ? $idwarehouse : 0;
	$result = $cn->validate($user, '', $wh);
	if ($result < 0) {
		$error++;
		$errmsg = $cn->error;
		$db->rollback();
	} else {
		$db->commit();
		$needwarehouse = 0; // Once validated, no longer ask for warehouse
	}
}

// Auto-validate if not requested warehouse
if ($creditnote_id > 0 && getDolGlobalInt('EASYBACK_AUTO_VALIDAR') && !$needwarehouse) {
	$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$cn->fetch($creditnote_id);
	if ($cn->status == 0) { // draft only
		$db->begin();
		$wh = getDolGlobalInt('EASYBACK_REINTEGRO_STOCK') ? $idwarehouse : 0;
		$result = $cn->validate($user, '', $wh);
		if ($result < 0) {
			$error++;
			$errmsg = $cn->error;
			$db->rollback();
		} else {
			$db->commit();
		}
	}
}

// Fetch credit note total and payments
if ($creditnote_id > 0 && !$error) {
	$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$cn->fetch($creditnote_id);
	$creditnote_total = abs((float) $cn->total_ttc);
	$currencycode = $cn->multicurrency_code ? $cn->multicurrency_code : $conf->currency;

	$src = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
	$src->fetch($facid);
	// List payments in the invoice currency so the bank reversal registers the
	// amount in the currency of the bank account at the invoice rate.
	$payments = $src->getListOfPayments('', 1);
}

llxHeader('', $langs->trans('EasyBackProcesarDevolucion'));

print '<div style="padding:10px;">';
print '<h3>'.$langs->trans('EasyBackProcesarDevolucion').'</h3>';

if ($error) {
	print '<div class="error">'.$langs->trans('Error').' : '.dol_escape_htmltag($errmsg).'</div>';
	print '<a class="butActionRefused" href="#" onclick="parent.jQuery(\'#idfordialogeasyback\').dialog(\'close\'); return false;">'.$langs->trans('EasyBackCerrar').'</a>';
} else {
	$cnref = '';
	if ($creditnote_id > 0) {
		$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
		$cn->fetch($creditnote_id);
		$cnref = $cn->ref;
	}
	// URL of the created credit note (avail. both in the payments and no-payments branches).
	$notaUrl = DOL_URL_ROOT.($isSupplier ? '/fourn/facture/card.php' : '/compta/facture/card.php').'?facid='.((int) $creditnote_id);

	print '<div class="ok">'.$langs->trans('EasyBackAbonoCreado', $cnref).'</div>';
	print '<br>';

	// If warehouse confirmation is needed
	if ($needwarehouse) {
		print '<h4>'.$langs->trans('EasyBackSelectWarehouse').'</h4>';
		print '<form method="post" action="'.$_SERVER['PHP_SELF'].'">';
		print '<input type="hidden" name="token" value="'.currentToken().'">';
		print '<input type="hidden" name="action" value="validate">';
		print '<input type="hidden" name="element" value="'.dol_escape_js($element).'">';
		print '<input type="hidden" name="facid" value="'.(int) $facid.'">';
		print '<input type="hidden" name="creditnote_id" value="'.(int) $creditnote_id.'">';
		print $formproduct->selectWarehouses(0, 'idwarehouse', '', 1, 0, '', 0);
		print '<br><br>';
		print '<button class="butAction" type="submit">'.$langs->trans('EasyBackValidarAbono').'</button>';
		print '</form>';

		print '</div>';
		llxFooter();
		$db->close();
		exit;
	}

	// Show payments for reversal
	print '<h4>'.$langs->trans('EasyBackPagosRealizados').'</h4>';

	if (count($payments) > 0) {
		print '<table class="noborder centpercent">';
		print '<tr class="liste_titre">';
		print '<th style="width:20px;"></th>';
		print '<th>'.$langs->trans('Payment').'</th>';
		print '<th class="right">'.$langs->trans('Amount').'</th>';
		print '<th class="right">'.$langs->trans('Date').'</th>';
		print '</tr>';
		foreach ($payments as $payment) {
			$amount = abs((float) $payment['amount']);
			$paytype = $payment['type'];
			// Resolve the bank account where this channel was originally paid, so
			// the reversal registers in the same bank (respects its currency).
			// Use the core AccountLine object instead of a raw SQL query.
			$bankacctid = 0;
			if (!empty($payment['fk_bank_line'])) {
				$bankline = new AccountLine($db);
				if ($bankline->fetch((int) $payment['fk_bank_line']) > 0) {
					$bankacctid = (int) $bankline->fk_account;
				}
			}
			print '<tr class="oddeven">';
			print '<td><input type="checkbox" name="easyback_payment[]" value="'.dol_escape_js($paytype).'" class="easyback-pay" data-amount="'.$amount.'" data-type="'.dol_escape_js($paytype).'" data-account="'.(int) $bankacctid.'"></td>';
			print '<td>'.$langs->trans('PaymentTypeShort'.$paytype).'</td>';
			print '<td class="right">'.price($amount).' '.$currencycode.'</td>';
			print '<td class="right">'.dol_print_date($db->jdate($payment['date']), 'day').'</td>';
			print '</tr>';
		}
		print '</table>';

		print '<div style="margin:12px 0;">';
		print $langs->trans('EasyBackMontoDevolver').' : <b>'.price($reving, 0, '', 1, -1, -1, $currencycode).'</b> &nbsp; ';
		print $langs->trans('EasyBackReversoTot').' : <b id="easyback-sel-total">0 '.$currencycode.'</b>';
		print '</div>';

		$ajaxurl = dol_buildpath('/easyback/return_ajax.php', 1);
		print '<button class="butAction" id="easyback-reverse-btn" onclick="EasyBackReverse()">'.$langs->trans('EasyBackProcesarReverso').'</button> &nbsp; ';
		print '<a class="butAction" href="#" onclick="parent.window.location.href = \''.dol_escape_js($notaUrl).'\'; return false;">'.$langs->trans('EasyBackVerNota').'</a> &nbsp; ';
		print '<a class="butActionRefused" href="#" onclick="parent.jQuery(\'#idfordialogeasyback\').dialog(\'close\'); parent.location.reload(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';

		print '<script>
var easybackAjaxUrl = "'.dol_escape_js($ajaxurl).'";
var easybackCreditnoteId = "'.(int) $creditnote_id.'";
var easybackElement = "'.dol_escape_js($isSupplier ? 'facture_fourn' : 'facture').'";
var easybackToken = "'.dol_escape_js(currentToken()).'";
var easybackMonto = "'.price2num($reving, 'MT').'";
var easybackCurrency = "'.dol_escape_js($currencycode).'";
var easybackNotaUrl = "'.dol_escape_js($notaUrl).'";
var easybackAviso = "'.dol_escape_js($langs->trans('EasyBackAviso')).'";
var easybackProcesar = "'.dol_escape_js($langs->trans('EasyBackProcesarDevolucion')).'";
function EasyBackUpdateSelTotal() {
    var total = 0;
    if ($("input.easyback-pay:checked").length > 0) { total = parseFloat(easybackMonto) || 0; }
    $("#easyback-sel-total").text(total.toFixed(2) + " " + easybackCurrency);
}
$(function() {
    $("input.easyback-pay").on("change", EasyBackUpdateSelTotal);
    EasyBackUpdateSelTotal();
});
function EasyBackReverse() {
    var payments = [];
    $("input.easyback-pay:checked").each(function() {
        payments.push({ type: $(this).attr("data-type"), weight: parseFloat($(this).attr("data-amount")), account: parseInt($(this).attr("data-account")) || 0 });
    });
    if (!payments.length) { parent.easybackNotification(easybackAviso, "'.dol_escape_js($langs->trans('EasyBackErrorSinPagos')).'"); return; }
    var data = { token: easybackToken, creditnote_id: easybackCreditnoteId, element: easybackElement, currency: easybackCurrency, monto_total: easybackMonto, payments: JSON.stringify(payments) };
    $.post(easybackAjaxUrl, data, function(resp) {
        if (resp.error) { parent.easybackNotification(easybackAviso, resp.error); }
        else {
            parent.easybackNotification(easybackProcesar, "'.dol_escape_js($langs->trans('EasyBackExito')).'", { url: easybackNotaUrl });
        }
    }, "json");
}
</script>';
	} else {
		print '<div class="opacitymedium">'.$langs->trans('EasyBackSinPagos').'</div>';
		print '<a class="butAction" href="#" onclick="parent.window.location.href = \''.dol_escape_js($notaUrl).'\'; return false;">'.$langs->trans('EasyBackVerNota').'</a> &nbsp; ';
		print '<a class="butActionRefused" href="#" onclick="parent.jQuery(\'#idfordialogeasyback\').dialog(\'close\'); parent.location.reload(); return false;">'.$langs->trans('EasyBackCerrar').'</a>';
	}
}

print '</div>';

llxFooter();
$db->close();
