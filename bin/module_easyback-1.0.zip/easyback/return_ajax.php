<?php
/* Copyright (C) 2026		Edgar Bustamante	<ebustamantep@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    easyback/return_ajax.php
 * \ingroup easyback
 * \brief   AJAX endpoint: register the bank reversal for the selected
 *          payments of a credit note (return).
 */

define('NOTOKENRENEWAL', 1);
define('NOREQUIREMENU', 1);
define('NOREQUIREHTML', 1);
define('NOREQUIREAJAX', 1);

// Load Dolibarr environment
$res = 0;
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/paiementfourn.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';

header('Content-Type: application/json; charset=UTF-8');

$langs->loadLangs(array('easyback@easyback', 'payments', 'banks'));

global $user;

$token = GETPOST('token', 'aZ09');
$creditnote_id = GETPOSTINT('creditnote_id');
$element = GETPOST('element', 'alpha');
$monto_total = (float) GETPOST('monto_total', 'alpha');   // amount to refund, in credit note currency
$payments = GETPOST('payments', 'none');    // JSON string array of {type, weight}

if (!isModEnabled('easyback')) {
	print json_encode(array('error' => 'Module not enabled'));
	exit;
}

// CSRF
if (!empty($conf->global->MAIN_SECURITY_CSRF_WITH_TOKEN) && !empty($token) && $token != currentToken()) {
	print json_encode(array('error' => $langs->trans('InvalidToken')));
	exit;
}

$isSupplier = ($element == 'facture_fourn' || $element == 'invoice_supplier');

// Permissions: replicate the native card.php logic (create + validate)
if ($isSupplier) {
	$usercancreate = ($user->hasRight('fournisseur', 'facture', 'creer') || $user->hasRight('supplier_invoice', 'creer'));
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('fournisseur', 'supplier_invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		print json_encode(array('error' => $langs->trans('NotEnoughPermissions')));
		exit;
	}
} else {
	$usercancreate = $user->hasRight('facture', 'creer');
	$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
		|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('facture', 'invoice_advance', 'validate')));
	if (!$usercancreate || !$usercanvalidate) {
		print json_encode(array('error' => $langs->trans('NotEnoughPermissions')));
		exit;
	}
}

if ($creditnote_id <= 0) {
	print json_encode(array('error' => $langs->trans('ErrorFieldRequired', 'creditnote_id')));
	exit;
}

$payments_arr = json_decode($payments, true);
if (!is_array($payments_arr) || count($payments_arr) == 0) {
	print json_encode(array('error' => $langs->trans('EasyBackErrorSinPagos')));
	exit;
}

// Load the credit note to get its total and currency
$cn = $isSupplier ? new FactureFournisseur($db) : new Facture($db);
if ($cn->fetch($creditnote_id) <= 0) {
	print json_encode(array('error' => $cn->error));
	exit;
}
// Selected amounts are sent in the currency of the credit note (invoice currency).
$creditnote_total = abs((float) $cn->multicurrency_total_ttc);
if (empty($creditnote_total)) {
	$creditnote_total = abs((float) $cn->total_ttc);
}

// Amount to refund = what is really returned in this attempt. It is bounded by
// the credit note total so the reversal never exceeds the credit note.
$monto_devolver = min((float) $monto_total, $creditnote_total);
if ($monto_devolver <= 0) {
	print json_encode(array('error' => $langs->trans('EasyBackErrorExcede')));
	exit;
}

// The marked channels are only used to pick a payment channel. The amount per
// channel is prorated by the original weight of that channel, so a partial
// return never reverses the full original payment.
$chanels = array();
$peso_total = 0;
foreach ($payments_arr as $p) {
	$paytype = isset($p['type']) ? $p['type'] : 'VIR';
	$peso = abs((float) (isset($p['weight']) ? $p['weight'] : 0));
	$accountid_orig = (int) (isset($p['account']) ? $p['account'] : 0);   // bank account where this channel was originally paid
	$chanels[] = array('type' => $paytype, 'peso' => $peso, 'account' => $accountid_orig, 'original' => $p);
	$peso_total += $peso;
}
if ($peso_total <= 0) {
	print json_encode(array('error' => $langs->trans('EasyBackErrorSinPagos')));
	exit;
}

$db->begin();

$error = 0;
$errmsg = '';

foreach ($chanels as $channel) {
	$monto_canal = ($peso_total > 0) ? price2num($monto_devolver * $channel['peso'] / $peso_total, 'MT') : 0;
	$amount = abs((float) $monto_canal);
	$paytype = $channel['type'];
	if ($amount <= 0) { continue; }

	// Determine the bank account for this reversal. Priority:
	//   1. The bank account where this channel was originally paid (data-account),
	//      so the reversal registers in the same bank and respects its currency.
	//   2. A bank account in the credit note currency (core requirement).
	//   3. The credit note account, then the first open account.
	$invoicecurrency = $cn->multicurrency_code ? $cn->multicurrency_code : $conf->currency;
	$accountid = $channel['account'];
	if (empty($accountid)) {
		if (!empty($invoicecurrency) && $invoicecurrency != $conf->currency) {
			$sql = "SELECT rowid FROM ".$db->prefix()."bank_account WHERE clos = 0 AND entity IN (".getEntity('bank_account').") AND currency_code = '".$db->escape($invoicecurrency)."' ORDER BY rowid";
			$resql = $db->query($sql);
			if ($resql) {
				$objacc = $db->fetch_object($resql);
				if ($objacc) {
					$accountid = $objacc->rowid;
				}
			}
		}
	}
	if (empty($accountid)) {
		$accountid = $cn->fk_account;
	}
	if (empty($accountid)) {
		$sql = "SELECT rowid FROM ".$db->prefix()."bank_account WHERE clos = 0 AND entity IN (".getEntity('bank_account').") ORDER BY rowid";
		$resql = $db->query($sql);
		if ($resql) {
			$objacc = $db->fetch_object($resql);
			if ($objacc) {
				$accountid = $objacc->rowid;
			}
		}
	}

	if (empty($accountid)) {
		$error++;
		$errmsg = $langs->trans('EasyBackErrorSinCuenta');
		break;
	}

	// Amount to refund is expressed in the credit note (invoice) currency.
	// The core Paiement::create() converts using the invoice rate stored on the
	// credit note, so we fill:
	//   - ->amounts              = amount in MAIN currency (llx_paiement.amount)
	//   - ->multicurrency_amounts = amount in the credit note currency
	// The bank account must be in the credit note currency (core requirement).
	// addPaymentToBank() then writes llx_bank.amount (bank/invoice currency) and
	// llx_bank.amount_main_currency (main currency).
	$invoice_rate = !empty($cn->multicurrency_tx) ? (float) $cn->multicurrency_tx : 1;

	$sign = -1;   // negative on a credit note (reversal)

	if ($invoicecurrency == $conf->currency) {
		// Credit note in main currency: same amount in both columns (rate = 1).
		$amount_main = abs($amount);
		$amount_invoice = abs($amount);
	} else {
		// Credit note in a foreign currency (e.g. VEF): ->amounts in main (USD),
		// ->multicurrency_amounts in the invoice/bank currency (VEF).
		$amount_invoice = abs($amount);
		$amount_main = price2num($amount_invoice / $invoice_rate, 'MT');   // main currency (USD)
	}

	if ($isSupplier) {
		$pay = new PaiementFourn($db);
		$pay->datepaye = dol_now();
		$pay->amounts = array($creditnote_id => $sign * $amount_main);
		$pay->multicurrency_amounts = array($creditnote_id => $sign * $amount_invoice);
		$pay->multicurrency_code = array($creditnote_id => $invoicecurrency);
		$pay->multicurrency_tx = array($creditnote_id => $invoice_rate);
		$pay->paiementcode = $paytype;
		$pay->paiementid = dol_getIdFromCode($db, $paytype, 'c_paiement', 'code', 'id', 1);
		$pay->num_payment = '';
		$pay->fk_account = $accountid;

		// closepaidinvoices = 1 so the core classifies the credit note as paid
		// (setPaid) once the reversal covers its full amount.
		$payment_id = $pay->create($user, 1);
		if ($payment_id < 0) {
			$error++;
			$errmsg = $pay->error;
			break;
		}

		$result = $pay->addPaymentToBank($user, 'payment_supplier', '(SupplierInvoicePayment)', $accountid, '', '');
		if ($result < 0) {
			$error++;
			$errmsg = $pay->error;
			break;
		}
	} else {
		$pay = new Paiement($db);
		$pay->datepaye = dol_now();
		$pay->amounts = array($creditnote_id => $sign * $amount_main);
		$pay->multicurrency_amounts = array($creditnote_id => $sign * $amount_invoice);
		$pay->multicurrency_code = array($creditnote_id => $invoicecurrency);
		$pay->multicurrency_tx = array($creditnote_id => $invoice_rate);
		$pay->paiementcode = $paytype;
		$pay->paiementid = dol_getIdFromCode($db, $paytype, 'c_paiement', 'code', 'id', 1);
		$pay->num_payment = '';
		$pay->fk_account = $accountid;

		// closepaidinvoices = 1 so the core classifies the credit note as paid
		// (setPaid) once the reversal covers its full amount.
		$payment_id = $pay->create($user, 1);
		if ($payment_id < 0) {
			$error++;
			$errmsg = $pay->error;
			break;
		}

		$result = $pay->addPaymentToBank($user, 'payment', '(CustomerInvoicePaymentBack)', $accountid, '', '');
		if ($result < 0) {
			$error++;
			$errmsg = $pay->error;
			break;
		}
	}
}

if ($error) {
	$db->rollback();
	print json_encode(array('error' => $errmsg ? $errmsg : $langs->trans('Error')));
} else {
	$db->commit();
	print json_encode(array('success' => true));
}

$db->close();
