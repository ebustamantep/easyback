# CHANGELOG MODULE EASYBACK FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.1

- Fix reembolso bancario parcial: el monto a devolver = total de lo realmente devuelto (abono), repartido proporcionalmente entre los canales de pago marcados. Antes se reversaba el monto completo del pago original.
- Abono validado reutilizado de un intento previo: se recalcula el monto a devolver a partir de las líneas/cantidades marcadas, evitando reversar el monto completo del abono.
- Fix multimoneda en el reverso bancario: el monto a devolver se calcula en la moneda de la factura/abono y se convierte a la moneda principal con la tasa de la factura. El banco destino se elige en la moneda del abono para respetar la moneda de la cuenta y registrar `llx_bank.amount` (moneda banco) con su equivalente `amount_main_currency` (moneda principal).
- Fix: al procesar el reembolso la factura de abono quedaba como pendiente de pago. Ahora `Paiement::create()`/`PaiementFourn::create()` se llaman con `closepaidinvoices=1` para que el core clasifique el abono como pagado (`setPaid` => `paye=1`, `fk_statut=STATUS_CLOSED`) cuando el reembolso cubre su importe.
- Fix: el reembolso iba a la primera cuenta de la lista en vez de la cuenta correcta. Ahora cada canal de pago lleva la cuenta bancaria donde se registró originalmente (`data-account`), y el reembolso se registra en esa misma cuenta (respetando su moneda). Si el canal no tiene cuenta, se usa una cuenta en la moneda del abono como fallback.

## 1.0

Initial version
