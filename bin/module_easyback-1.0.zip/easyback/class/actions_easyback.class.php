<?php
/* Copyright (C) 2026		Edgar Bustamante	<ebustamantep@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    class/actions_easyback.class.php
 * \ingroup easyback
 * \brief   Hooks for customer and supplier invoices: replace the native
 *          "Create credit note" flow by a single "Devolución" button.
 */

require_once DOL_DOCUMENT_ROOT.'/core/class/commonhookactions.class.php';

/**
 * Class ActionsEasyback
 */
class ActionsEasyback extends CommonHookActions
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 * @var string[] Errors
	 */
	public $errors = array();

	/**
	 * @var mixed[] Hook results.
	 */
	public $results = array();

	/**
	 * @var ?string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 * @var int Priority of hook (50 if not defined)
	 */
	public $priority = 50;

	/**
	 * Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * addHtmlHeader. Inject JS/CSS on the customer and supplier invoice cards.
	 *
	 * @param array<string,mixed> $parameters Hook metadata
	 * @param CommonObject        $object    The object
	 * @param string              $action    Current action (if set)
	 * @param HookManager         $hookmanager Hook manager
	 * @return int <0 on error, 0 on success
	 */
	public function addHtmlHeader($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $langs;

		$this->resprints = '';

		// Only on the invoice cards (customer and supplier).
		$script = isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : '';
		if (strpos($script, '/compta/facture/card.php') === false && strpos($script, '/fourn/facture/card.php') === false) {
			return 0;
		}

		$langs->load('easyback@easyback');

		$returnurl = dol_buildpath('/easyback/return.php', 1);
		$token = currentToken();
		$isSupplier = (strpos($script, '/fourn/facture/card.php') !== false);

		$enableVenta = getDolGlobalInt('EASYBACK_DEVOLUCION_VENTA');
		$enableCompra = getDolGlobalInt('EASYBACK_DEVOLUCION_COMPRA');
		if (($isSupplier && !$enableCompra) || (!$isSupplier && !$enableVenta)) {
			return 0;
		}

		$procesar = $langs->trans('EasyBackProcesarDevolucion');
		$seleccion = $langs->trans('EasyBackSeleccionLineas');
		$cancelar = $langs->trans('EasyBackCancelar');

		$this->resprints = '<style>
.easyback-col { width: 90px; text-align: center; }
.easyback-col input[type="number"] { width: 60px; text-align: right; }
.easyback-toolbar { margin: 6px 0; }
</style>
<div id="idfordialogeasyback" class="hidden"></div>
<script>
var easybackReturnUrl = "'.dol_escape_js($returnurl).'";
var easybackToken = "'.dol_escape_js($token).'";
var easybackElement = "'.($isSupplier ? 'facture_fourn' : 'facture').'";
var easybackProcesar = "'.dol_escape_js($procesar).'";
var easybackSeleccion = "'.dol_escape_js($seleccion).'";
var easybackCancelar = "'.dol_escape_js($cancelar).'";
var easybackActive = false;
var easybackFacid = 0;
var easybackLblVerNota = "'.dol_escape_js($langs->trans('EasyBackVerNota')).'";
var easybackLblCerrar = "'.dol_escape_js($langs->trans('EasyBackCerrar')).'";
var easybackLblAceptar = "'.dol_escape_js($langs->trans('EasyBackAceptar')).'";

// Native-looking confirmation/notice dialog on the PARENT page (which already
// loads jQuery UI from the core). Called from inside the iframe as
// parent.easybackNotification(...). With options.url it shows "Ver nota" (goto)
// and "Cerrar" (reload original); otherwise a single "Aceptar" button.
function easybackNotification(title, message, options) {
    options = options || {};
    jQuery(\'#easyback-notify\').remove();
    var $d = jQuery(\'<div id="easyback-notify" class="confirmmessage" style="display:none;">\' + message + \'</div>\');
    jQuery(\'body\').append($d);
    var buttons = {};
    if (options.url) {
        buttons[options.yesLabel || easybackLblVerNota] = function() {
            jQuery(this).dialog(\'close\');
            window.location.href = options.url;
        };
        buttons[options.noLabel || easybackLblCerrar] = function() {
            jQuery(this).dialog(\'close\');
            window.location.reload();
        };
    } else {
        buttons[options.okLabel || easybackLblAceptar] = function() {
            jQuery(this).dialog(\'close\');
            if (options.reload) window.location.reload();
        };
    }
    $d.dialog({
        modal: true,
        resizable: false,
        width: 500,
        title: title,
        buttons: buttons
    });
    $d.on(\'dialogclose\', function() { jQuery(this).remove(); });
}

// Parse a formatted amount into a number. Supports both "1,234.56" (en) and
// "1.234,56" (es) by treating the last separator as the decimal separator.
function easybackParseAmount(s) {
    s = String(s || "").replace(/[^0-9.,-]/g, "");
    if (!s) { return 0; }
    var lastComma = s.lastIndexOf(",");
    var lastDot = s.lastIndexOf(".");
    if (lastComma > -1 && lastDot > -1) {
        // Whichever comes last is the decimal separator.
        if (lastComma > lastDot) {
            s = s.replace(/\./g, "").replace(",", ".");
        } else {
            s = s.replace(/,/g, "");
        }
    } else if (lastComma > -1) {
        // Only commas: if more than one, they are thousands; a single one at end is decimal.
        if ((s.match(/,/g) || []).length > 1) {
            s = s.replace(/,/g, "");
        } else {
            s = s.replace(",", ".");
        }
    } else if (lastDot > -1) {
        // Only dots: if more than one, they are thousands.
        if ((s.match(/\./g) || []).length > 1) {
            s = s.replace(/\./g, "");
        }
    }
    return parseFloat(s) || 0;
}

// Hide the native "Create credit note" button.
$(document).ready(function() {
    $("a[href*=\\"type=2\\"]").each(function() {
        var h = $(this).attr("href") || "";
        if (h.indexOf("action=create") !== -1 || h.indexOf("action%3Dcreate") !== -1) {
            $(this).hide();
        }
    });
});

function EasyBackToggleMode(facid) {
    var table = $("#tablelines");
    if (!table.length) { return; }
    if (!easybackActive) {
        easybackActive = true;
        easybackFacid = facid || 0;
        // Add header column
        var thead = table.find("thead > tr");
        if (thead.length && !thead.find(".easyback-col").length) {
            thead.prepend("<th class=\\"easyback-col\\">Sel.</th>");
        }
        // Add cells + toolbar
        table.find("tbody tr[data-id]").each(function() {
            var row = $(this);
            var lineid = row.attr("data-id");
            var qty = row.attr("data-qty") || "1";
            if (row.find(".easyback-col").length) { return; }

            // Remember the original unit price (HT) so we can recompute the line total
            // when the operator edits the quantity. Use the HT total / original qty.
            var htTotalCell = row.find("td.linecolht");
            var htTotalVal = htTotalCell.find(".classfortooltip").first().text() || htTotalCell.first().text() || "";
            var htTotal = easybackParseAmount(String(htTotalVal));
            var unitPrice = qty ? (htTotal / parseFloat(qty)) : 0;
            row.data("easyback-unitprice", unitPrice);

            var cell = $("<td class=\\"easyback-col\\"></td>");
            cell.append("" +
                "<input type=\\"checkbox\\" class=\\"easyback-line-check\\" name=\\"easyback_lineid[]\\" value=\\"" + lineid + "\\">" +
                "<input type=\\"number\\" class=\\"easyback-qty\\" name=\\"easyback_qty[" + lineid + "]\\" value=\\"" + qty + "\\" min=\\"1\\" step=\\"any\\">"
            );
            row.prepend(cell);
        });

        // Recompute the line HT total cell when quantity changes.
        table.find("tbody tr[data-id]").on("change", "input.easyback-qty", function() {
            var row = $(this).closest("tr");
            var qty = parseFloat($(this).val()) || 0;
            var unitPrice = parseFloat(row.data("easyback-unitprice")) || 0;
            var newTotal = unitPrice * qty;
            var htCell = row.find("td.linecolht");
            var tooltip = htCell.find(".classfortooltip").first();
            if (tooltip.length) {
                // Update text content but keep the tooltip title intact.
                tooltip.text(newTotal ? newTotal.toFixed(2) : "0.00");
            } else {
                htCell.first().text(newTotal ? newTotal.toFixed(2) : "0.00");
            }
        });

        EasyBackShowToolbar(true);
        // Uncheck empty non-product lines by default? keep simple: require at least one checked.
    } else {
        EasyBackToggleModeOff();
    }
}

function EasyBackToggleModeOff() {
    easybackActive = false;
    $("#tablelines thead .easyback-col").remove();
    $("#tablelines .easyback-col").remove();
    EasyBackShowToolbar(false);
}

function EasyBackShowToolbar(show) {
    if (show) {
        if ($("#easyback-toolbar").length) { return; }
        var bar = $("<div class=\\"easyback-toolbar\\" id=\\"easyback-toolbar\\"></div>");
        bar.append("<span class=\\"opacitymedium\\">&nbsp;" + easybackSeleccion + "</span> ");
        bar.append("<button type=\\"button\\" class=\\"butAction\\" onclick=\\"EasyBackSubmit()\\">&nbsp;" + easybackProcesar + "</button> ");
        bar.append("<a class=\\"butActionRefused\\" href=\\"#\\" onclick=\\"EasyBackToggleModeOff(); return false;\\">&nbsp;" + easybackCancelar + "</a>");
        // Insert before the table
        $("#tablelines").before(bar);
    } else {
        $("#easyback-toolbar").remove();
    }
}

function EasyBackSubmit() {
    var any = false;
    var lines = [];
    $("#tablelines").find("tr[data-id]").each(function() {
        var row = $(this);
        var cb = row.find("input.easyback-line-check");
        if (cb.is(":checked")) {
            any = true;
            var lineid = cb.val();
            var qty = row.find("input.easyback-qty").val() || "1";
            lines.push({lineid: lineid, qty: qty});
        }
    });
    if (!any) {
        easybackNotification(easybackSeleccion, "'.dol_escape_js($langs->trans('EasyBackErrorSinLineas')).'");
        return;
    }
    var url = easybackReturnUrl + "?token=" + encodeURIComponent(easybackToken) +
        "&facid=" + encodeURIComponent(easybackFacid) +
        "&element=" + encodeURIComponent(easybackElement);
    for (var i = 0; i < lines.length; i++) {
        url += "&lineid[]=" + encodeURIComponent(lines[i].lineid) +
               "&qty[" + encodeURIComponent(lines[i].lineid) + "]=" + encodeURIComponent(lines[i].qty);
    }
    // Native Dolibarr popup: jQuery UI dialog with an iframe.
    var $dialog = $("#idfordialogeasyback");
    $dialog.html("<iframe class=\"iframedialog\" style=\"border:0px;\" src=\"" + url + "\" width=\"100%\" height=\"98%\"></iframe>");
    $dialog.dialog({
        autoOpen: true,
        modal: true,
        height: (window.innerHeight - 150),
        width: "85%",
        title: easybackProcesar,
        close: function() { $dialog.html(""); }
    });
}
</script>';

		return 0;
	}

	/**
	 * addMoreActionsButtons. Add the "Devolución" button to the invoice action bar.
	 *
	 * @param array<string,mixed> $parameters Hook metadata
	 * @param CommonObject        $object    The object
	 * @param string              $action    Current action (if set)
	 * @param HookManager         $hookmanager Hook manager
	 * @return int <0 on error, 0 on success
	 */
	public function addMoreActionsButtons($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $langs, $user;

		$langs->load('easyback@easyback');

		if (!is_object($object)) {
			return 0;
		}

		$isSupplier = ($object->element == 'invoice_supplier');
		$isCustomer = ($object->element == 'facture');

		if (!$isSupplier && !$isCustomer) {
			return 0;
		}

		if ($isSupplier && !getDolGlobalInt('EASYBACK_DEVOLUCION_COMPRA')) {
			return 0;
		}
		if ($isCustomer && !getDolGlobalInt('EASYBACK_DEVOLUCION_VENTA')) {
			return 0;
		}

		// Only for invoices that can be credited: not a credit note, status validated/closed, has status > 0.
		if ($object->type == 2) { // Already a credit note (TYPE_CREDIT_NOTE)
			return 0;
		}
		if ((int) $object->status <= 0) {
			return 0;
		}

		// Replicate the native permission logic (card.php) so the button shows
		// under the same conditions the core would allow creating a credit note.
		$usercanvalidate = false;
		if ($isSupplier) {
			$usercancreate = ($user->hasRight('fournisseur', 'facture', 'creer') || $user->hasRight('supplier_invoice', 'creer'));
			$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
				|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('fournisseur', 'supplier_invoice_advance', 'validate')));
		} else {
			$usercancreate = $user->hasRight('facture', 'creer');
			$usercanvalidate = ((!getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $usercancreate)
				|| (getDolGlobalString('MAIN_USE_ADVANCED_PERMS') && $user->hasRight('facture', 'invoice_advance', 'validate')));
		}

		if (!$usercanvalidate) {
			return 0;
		}

		print '<a class="butAction reposition" href="#" onclick="EasyBackToggleMode('.(int) $object->id.'); return false;">'.$langs->trans('EasyBackDevolucion').'</a>';

		return 0;
	}
}
